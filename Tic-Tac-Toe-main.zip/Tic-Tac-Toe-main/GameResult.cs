﻿namespace TicTacToe
{
    public class GameResult
    {
        public Player Winner { get; set; }
        public WinInfo WinInfo { get; set; }
    }
}
