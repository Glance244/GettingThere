# Tic-Tac-Toe

Source code for a Tic-Tac-Toe game written in C# using WPF for the UI.

Here is a full step-by-step video of the development:
https://www.youtube.com/watch?v=OHRWRpT9WcE
