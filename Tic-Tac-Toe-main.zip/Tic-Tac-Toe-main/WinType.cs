﻿namespace TicTacToe
{
    public enum WinType
    {
        Row, Column, MainDiagonal, AntiDiagonal
    }
}
